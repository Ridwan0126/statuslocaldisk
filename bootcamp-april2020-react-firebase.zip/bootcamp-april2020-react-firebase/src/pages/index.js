import Form from "./form";
import List from "./list";
import Login from "./login";
import Register from "./register";
import Detail from "./detail";
import Firestore from "./firestore";

export { Form, List, Login, Register, Detail, Firestore }