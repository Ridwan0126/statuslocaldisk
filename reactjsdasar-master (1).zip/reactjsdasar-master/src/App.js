import React from 'react';
import Navbar from './Navbar'
import Header from './Header';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Header />
      <h2>Hello World</h2>
    </div>
  );
}

export default App;
