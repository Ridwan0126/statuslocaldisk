import Header from "./header";
import Nav from "./navigation";
import Body from "./body";

export { Header, Nav, Body }