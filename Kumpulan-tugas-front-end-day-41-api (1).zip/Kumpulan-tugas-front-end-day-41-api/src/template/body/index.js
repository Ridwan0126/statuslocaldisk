import React, { Component } from "react";
import { UserList, Home, Login, Register } from "../../page";

let studentList = [
  { id: 1, name: "John Doe", username: "admin", address: "address" },
  { id: 2, name: "Jane Doe", username: "admin", address: "address" },
  { id: 3, name: "Terry Adams", username: "admin", address: "address" },
  { id: 4, name: "Jenny Smith", username: "admin", address: "address" },
];
// let studentList = [
//   { id: 1, name: "John Doe", username: "admin", school: "School" },
//   { id: 2, name: "Jane Doe", username: "admin", school: "School" },
//   { id: 3, name: "Terry Adams", username: "admin", school: "School" },
//   { id: 4, name: "Jenny Smith", username: "admin", school: "School" },
// ];

if (localStorage.getItem("students") === null)
  localStorage.setItem("students", JSON.stringify(studentList));

class Body extends Component {
  constructor(props) {
    super(props);
    this.state = {
      studentList: [],
      statusEdit: false,
      index: 0,
    };
    // this.editStudentSubmit = this.editStudentSubmit.bind(this);
    // this.deleteStudent = this.deleteStudent.bind(this);
    // this.addNewStudent = this.registerHandler.bind(this);
    console.log("isi student : ", this.state.studentList);
  }
  componentWillMount = () => {
    studentList = JSON.parse(localStorage.getItem("students"));

    this.setState((prevState, props) => ({
      studentList: studentList,
    }));
  };

  componentDidMount = () => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => response.json())
      .then((json) => {
        this.setState({
          studentList: json.map((user) => {
            return {
              id: user.id,
              name: user.name,
              username: user.username,
              password: "12345",
              address: user.address.city,
            };
          }),
        });
      });
  };

  deleteStudent = (id) => {
    let r = window.confirm("Do you want to delete this item");
    if (r === true) {
      let filteredStudentList = this.state.studentList.filter(
        (x) => x.id !== id
      );

      this.setState((prevState, props) => ({
        studentList: filteredStudentList,
      }));
      localStorage.setItem("students", JSON.stringify(filteredStudentList));
    }
  };

  editStudentSubmit = (id, name, username, address) => {
    let studentListCopy = this.state.studentList.map((student) => {
      if (student.id === id) {
        student.name = name;
        student.username = username;
        student.address = address;
      }
      return student;
    });
    this.setState((prevState, props) => ({
      studentList: studentListCopy,
    }));
    localStorage.setItem("students", JSON.stringify(studentListCopy));
  };

  addNewStudent = (newUser) => {
    console.log("data baru", newUser);
    console.log(this.state.studentList);

    let copyStudent = this.state.studentList;
    newUser.id = copyStudent.length + 1;

    copyStudent.push(newUser);

    this.setState({
      studentList: copyStudent,
    });

    localStorage.setItem("students", JSON.stringify(copyStudent));
  };

  statusEdit = (id) => {
    this.setState({
      statusEdit: true,
      index: id,
    });
  };

  editStudentExist = (newUser) => {
    // newUser.preventDefault();
    console.log("data baruuuuuuuuuuuuu", newUser);
    console.log(this.state.studentList);

    let copyStudent = this.state.studentList;
    console.log("ini copy student : ", copyStudent);

    copyStudent.splice(this.state.index, 1, newUser);
    this.setState({
      studentList: copyStudent,
    });

    localStorage.setItem("students", JSON.stringify(copyStudent));
  };

  // masih error
  // loginUserHandler = (user) => {
  //   this.props.loginUserHandler(user);
  // };

  moveToLogin = () => {
    this.props.loginPage("login");
  };

  renderPage = () => {
    const page = this.props.page;
    const loginPage = this.props.goToPage;
    const registerPage = this.props.goToPage;
    if (page === "userList")
      return (
        <UserList
          dataList={this.state.studentList}
          deleteList={this.deleteStudent}
          editList={this.editStudentSubmit}
          loginPage={loginPage}
          registerPage={registerPage}
          statusEdit={this.statusEdit}
          // loggedUser={this.props.loggedUser} masih error
        />
      );

    if (page === "register")
      return (
        <Register
          registerHandler={this.addNewStudent}
          loginPage={loginPage}
          statusEdit={this.state.statusEdit}
          editStudentExist={this.editStudentExist}
        />
      );
    if (page === "login")
      return (
        <Login
          // loginUserHandler={this.loginUserHandler} masih error
          login={this.state.studentList}
          loginPage={loginPage}
          registerPage={registerPage}
        />
      );

    return <Home loginPage={loginPage} />;
  };

  render() {
    console.log("ini state baru", this.state);
    return <div className="body">{this.renderPage()}</div>;
  }
}

export default Body;
