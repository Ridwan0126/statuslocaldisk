import React, { Component } from "react";
import { Header, Nav, Body } from "./template";
import "./App.css";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentPage: "home",
      // masih error
      // loginUser: {
      //   username: "",
      // },
    };
  }

  changePage = (page) => {
    this.setState({
      currentPage: page,
    });
  };

  loginUserHandler = (user) => {
    this.setState({
      loginUser: user,
    });
  };

  render() {
    return (
      <>
        {/* <Header /> */}
        <Nav page={this.state.currentPage} goToPage={this.changePage} />
        <Body
          page={this.state.currentPage}
          goToPage={this.changePage}
          // loginUserHandler={this.loginUserHandler}  masih error
          // loggedUser={this.state.loginUser} masih error
        />
      </>
    );
  }
}

export default App;

/**
 * ======== KONSEP NAVIGATION ========
 * App: <= buat state disini
 *    - Nav:
 *          - Menu
 *    - Body
 */

/**
 * Latihan:
 *        - Convert halaman HTML ke dalam React (header, body, table, pagination)
 *
 *
 * Latihan:
 *        - Buat login page dengan verifikasi username & password
 *        - Fungsikan fitur Add, Edit & Delete pada list data sebelumnya
 *        - Pagination Google harus berfungsi
 *
 *
 * Latihan:
 *        - Buat pagination untuk login, register dan list user
 *        - Setiap user yang register, masuk ke daftar list user
 *        - Setiap user yang login, ngecek data ke list user
 *        - Terapkan atomic design
 */
