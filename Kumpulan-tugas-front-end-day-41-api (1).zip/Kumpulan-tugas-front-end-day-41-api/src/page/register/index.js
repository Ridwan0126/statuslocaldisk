import React, { Component } from "react";
import "./register.css";
import Swal from "sweetalert2";

/* Render Call
-------------------------------------------------*/
// ReactDOM.render(<App />, document.getElementById("app"));

class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  // editStudentSubmit = () => {
  //   const { id } = this.props.student;
  //   this.setState((prevState, props) => ({
  //     isEdit: !prevState.isEdit,
  //   }));
  //   this.props.editStudentSubmit(
  //     id,
  //     this.nameInput.value,
  //     this.usernameInput.value,
  //     this.schoolInput.value
  //   );
  // };

  registerHandler = (e) => {
    e.preventDefault();
    const user = {
      name: e.target[0].value,
      username: e.target[1].value,
      address: e.target[2].value,
    };
    console.log(user);
    if (this.props.statusEdit) {
      this.props.editStudentExist(user);
      const { loginPage } = this.props;
      loginPage("userList");
    } else {
      this.props.registerHandler(user);
      Swal.fire("TOP !!!", "Succesfully Register", "success");
      this.props.loginPage("login");
    }

    console.log("ini register nbr", user);
  };

  moveToLogin = () => {
    this.props.loginPage("login");
  };

  render() {
    const statusEdit = this.props.statusEdit;
    return (
      <>
        <br />
        <br />
        <br />
        <br />

        <h1> {statusEdit ? "EDIT STUDENT" : "REGISTER"} </h1>

        <div className="App">
          <form className="form" onSubmit={this.registerHandler}>
            <div className="input-group">
              <label>Name : </label>
              <input type="text" name="name" placeholder="Name" />
            </div>
            <div className="input-group">
              <label>Username : </label>
              <input type="text" name="username" placeholder="Username" />
            </div>
            <div className="input-group">
              <label>Address : </label>
              <input type="text" name="password" placeholder="School" />
            </div>
            <div className="input-group">
              <label>Password : </label>
              <input type="text" placeholder="Password" />
            </div>
            {statusEdit ? (
              <button className="btn1" type="submit">
                SAVE
              </button>
            ) : (
              <>
                <button className="btn1" type="submit">
                  SIGN UP
                </button>
                <button className="btn1" onClick={this.moveToLogin}>
                  LOGIN
                </button>
              </>
            )}
          </form>
        </div>

        {/* {this.props.login} */}
      </>
    );
  }
}

export default Register;
