import UserList from "./userlist";
import Home from "./home";
import Login from "./login";
import Register from "./register";

export { Home, UserList, Login, Register };
