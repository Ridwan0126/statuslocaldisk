import React, { Component } from "react";
import "./login.css";
import Swal from "sweetalert2";

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  // login
  handleSubmit = (e) => {
    e.preventDefault();
    console.log("ini e ", e.target.username.value);

    const { login } = this.props;
    console.log("ini login panjang", login.length);

    for (let i = 0; i < login.length; i++) {
      console.log("ini login for", login[i]);

      let usernameValue = e.target.username.value;

      if (!usernameValue) {
        return Swal.fire("Oh Nooo !!!", "username not valid", "error");
      } else if (!usernameValue) {
        return Swal.fire("Oh Nooo !!!", "username not valid", "error");
      } else if (!e.target.password.value) {
        return Swal.fire("Oh Nooo !!!", "password not valid", "error");
      } else if (
        usernameValue === login[i].username &&
        e.target.password.value === "12345"
      ) {
        //
        console.log(login[i]);
        // masih error
        // this.props.loginUserHandler(login[i]);
        const { loginPage } = this.props;
        loginPage("userList");
        return Swal.fire("TOP !!!", "Login in", "success");
      }
    }

    return alert("salah username password");
  };

  moveToRegister = (e) => {
    e.preventDefault();
    this.props.loginPage("register");
  };
  // end login

  render() {
    return (
      <>
        <br />
        <br />
        <br />
        <br />
        <br />
        <h1 className="active">LOGIN</h1>

        <div className="App">
          <form className="form-container" onSubmit={this.handleSubmit}>
            <div className="input-group">
              <label>Username : </label>
              <input type="text" name="username" placeholder="Username" />
            </div>
            <div className="input-group">
              <label>Password : </label>
              <input type="text" name="password" placeholder="Password" />
            </div>
            <button className="btn1">Sign In</button>
            <button className="btn1" onClick={this.moveToRegister}>
              REGISTER
            </button>
          </form>
        </div>
      </>
    );
  }
}

export default Login;
