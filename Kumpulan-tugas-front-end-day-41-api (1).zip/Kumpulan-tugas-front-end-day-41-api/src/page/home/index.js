import React, { Component } from "react";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  moveToLogin = (e) => {
    e.preventDefault();
    this.props.loginPage("register");
  };
  moveToRegister = (e) => {
    e.preventDefault();
    this.props.loginPage("login");
  };

  render() {
    const photo =
      "https://images.unsplash.com/photo-1626555007919-57d025f14170?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1782&q=80";
    return (
      <>
        <h1>PESBUUUUKKKKKKKKKKKK</h1>

        <div id="buton">
          <button className="btn1" onClick={this.moveToLogin}>
            REGISTER
          </button>
          <button className="btn1" onClick={this.moveToRegister}>
            LOGIN
          </button>
        </div>
        <div className="Appp">
          <img width="90%" src={photo} alt="Phot" />
        </div>
      </>
    );
  }
}

export default Home;
