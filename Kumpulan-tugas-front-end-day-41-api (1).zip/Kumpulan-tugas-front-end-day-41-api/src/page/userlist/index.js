import React, { Component } from "react";
import "./userlist.css";
import StudentList from "./StudentList.jsx";

class UserList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: this.props.dataList,
    };
    console.log("inidata :", this.state);
  }

  moveToLogin = () => {
    this.props.loginPage("login");
    return alert("logout");
  };

  render() {
    const { dataList, deleteList, editList, registerPage } = this.props;

    return (
      <>
        <br />
        <br />

        <h1>TABLE CRUD AND PAGINATION REACT JS</h1>
        <button className="btn1" onClick={this.addNewStudent}>
          Add New
        </button>
        <input
          type="text"
          id="search"
          name="search"
          placeholder="Search for names.."
          title="Type in a name"
        />

        <table border="0" id="employeeList" className="tbl">
          <thead className="tbl-header">
            <tr>
              <th>Name</th>
              <th>Username</th>
              <th>Address</th>
              <th>Edit/Save</th>
              <th>Delete</th>
            </tr>
          </thead>
          <StudentList
            deleteStudent={deleteList}
            studentList={dataList}
            editStudentSubmit={editList}
            registerPage={registerPage}
            statusEdit={this.props.statusEdit}
            // loggedUser={this.props.loggedUser}  masih error
          />
        </table>
        <button className="btn1" onClick={this.moveToLogin}>
          LOGOUT
        </button>
        <div id="demo" className="pagination">
          <span>1</span>
          <span>2</span>
          <span>3</span>
          <span>4</span>
          <span>5</span>
          <span>Next</span>
          <span>Last Page</span>
        </div>
      </>
    );
  }
}

export default UserList;

// const studentList = [
//   { id: 1, name: "John Doe", username: 1, school: "React Redux School" },
//   { id: 2, name: "Jane Doe", username: 2, school: "React Redux School" },
//   { id: 3, name: "Terry Adams", username: 3, school: "React Redux School" },
//   { id: 4, name: "Jenny Smith", username: 4, school: "React Redux School" },
// ];

// const studentList = this.state.dataList;
// if (localStorage.getItem("students") === null)
//   localStorage.setItem("students", JSON.stringify(studentList));

// componentWillMount() {
//   let studentList = JSON.parse(localStorage.getItem("students"));

//   this.setState((prevState, props) => ({
//     studentList: studentList,
//   }));
// }
// addNewStudent() {
//   this.setState((prevState, props) => ({
//     studentList: [
//       ...prevState.studentList,
//       {
//         id:
//           Math.max(
//             ...prevState.studentList.map(function (o) {
//               return o.id;
//             })
//           ) + 1,
//         name: "",
//         username: "",
//         school: "",
//       },
//     ],
//   }));
// }

// deleteStudent(id) {
//   let r = window.confirm("Do you want to delete this item");
//   if (r === true) {
//     let filteredStudentList = this.state.studentList.filter(
//       (x) => x.id !== id
//     );

//     this.setState((prevState, props) => ({
//       studentList: filteredStudentList,
//     }));
//     localStorage.setItem("students", JSON.stringify(filteredStudentList));
//   }
// }
// editStudentSubmit(id, name, username, school) {
//   let studentListCopy = this.state.studentList.map((student) => {
//     if (student.id === id) {
//       student.name = name;
//       student.username = username;
//       student.school = school;
//     }
//     return student;
//   });
//   this.setState((prevState, props) => ({
//     studentList: studentListCopy,
//   }));
//   localStorage.setItem("students", JSON.stringify(studentListCopy));
// }

// // LOGIN //
// handleSubmit = (e) => {
//   e.preventDefault();
//   console.log(e.target.email.value);

//   if (!e.target.email.value) {
//     alert("Email salah");
//   } else if (!e.target.email.value) {
//     alert("email masih salah");
//   } else if (!e.target.password.value) {
//     alert("Password salah");
//   } else if (
//     e.target.email.value === "admin" &&
//     e.target.password.value === "admin"
//   ) {
//     alert("Successfully login");
//     e.target.email.value = "";
//     e.target.password.value = "";
//   } else {
//     alert("salah email atau password");
//   }
// };

// handleClick = (e) => {
//   e.preventDefault();

//   alert("BARU IMAJINASI AJA");
// };
