import React, { Component } from "react";

export default class StudentItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isEdit: false,
      // masih error
      // loggedUser: {
      //   username: "",
      // },
    };
    this.editStudent = this.editStudent.bind(this);
    this.editStudentSubmit = this.editStudentSubmit.bind(this);
    this.deleteStudent = this.deleteStudent.bind(this);
  }
  // masih error
  //   componentDidMount = () => {
  //     const { loggedUser } = this.props;
  //     this.setState({
  //       loggedUser: loggedUser,
  //     });
  //   };

  deleteStudent() {
    const { id } = this.props.student;
    this.props.deleteStudent(id);
  }

  editStudent(e) {
    this.setState((prevState, props) => ({
      isEdit: !prevState.isEdit,
    }));
    this.props.statusEdit(e.target.id);

    this.props.registerPage("register"); // ini untuk ke register
  }

  editStudentSubmit() {
    const { id } = this.props.student;
    this.setState((prevState, props) => ({
      isEdit: !prevState.isEdit,
    }));
    this.props.editStudentSubmit(
      id,
      this.nameInput.value,
      this.usernameInput.value,
      this.schoolInput.value
    );
  }

  render() {
    const { name, username, address } = this.props.student;
    return this.state.isEdit === true ? (
      <tr className="bg-warning" key={this.props.index}>
        <td>
          <input
            ref={(nameInput) => (this.nameInput = nameInput)}
            defaultValue={name}
          />
        </td>
        <td>
          <input
            defaultValue={username}
            ref={(usernameInput) => (this.usernameInput = usernameInput)}
          />
        </td>
        <td>
          <input
            ref={(schoolInput) => (this.schoolInput = schoolInput)}
            defaultValue={address}
          />
        </td>
        <td>
          <i className="far fa-save" onClick={this.editStudentSubmit}></i>
        </td>
        <td>
          <i className="fas fa-trash"></i>
        </td>
      </tr>
    ) : (
      <tr key={this.props.index}>
        <td>{name}</td>
        <td>{username}</td>
        <td>{address}</td>
        <td>
          <i
            id={this.props.index}
            className="far fa-edit"
            onClick={this.editStudent}
          ></i>
        </td>
        <td>
          <i className="fas fa-trash" onClick={this.deleteStudent}></i>
        </td>
      </tr>
    );
  }
}
